(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[185],{93890:function(e,t,r){Promise.resolve().then(r.t.bind(r,58877,23)),Promise.resolve().then(r.bind(r,23814))},23814:function(e,t,r){"use strict";r.d(t,{Sidebar:function(){return p}});var n=r(57437),a=r(2265),l=r(81066);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,l.Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);var s=r(55715),c=r(24241),h=r(37663);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let d=(0,l.Z)("History",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M12 7v5l4 2",key:"1fdv2h"}]]);var o=r(22023),y=r(33907),u=r(52022),x=r(74697);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let m=(0,l.Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]),f=(0,l.Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]]),k=[{href:"index.html",label:"概览",icon:i},{href:"entry.html",label:"每日录入",icon:s.Z},{href:"daily-supplements.html",label:"今日服用",icon:c.Z},{href:"supplements-library.html",label:"补剂库",icon:h.Z},{href:"history.html",label:"历史记录",icon:d},{href:"reports.html",label:"体检报告",icon:o.Z},{href:"ai-insights.html",label:"AI 指导",icon:y.Z},{href:"profile.html",label:"个人资料",icon:u.Z}];function p(){let[e,t]=(0,a.useState)(!1),r=()=>{window.innerWidth<1024&&t(!1)};return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("button",{onClick:()=>t(!e),className:"fixed top-4 left-4 z-50 lg:hidden p-2 bg-white rounded-lg shadow-md border border-gray-200",children:e?(0,n.jsx)(x.Z,{className:"w-5 h-5"}):(0,n.jsx)(m,{className:"w-5 h-5"})}),e&&(0,n.jsx)("div",{className:"fixed inset-0 bg-black/50 z-40 lg:hidden",onClick:()=>t(!1)}),(0,n.jsxs)("aside",{className:"\n        fixed top-0 left-0 bottom-0 w-64 bg-white border-r border-gray-200 z-50 flex flex-col\n        transform transition-transform duration-300 ease-in-out\n        lg:translate-x-0\n        ".concat(e?"translate-x-0":"-translate-x-full","\n      "),children:[(0,n.jsx)("div",{className:"p-5 border-b border-gray-100",children:(0,n.jsxs)("a",{href:"index.html",className:"flex items-center gap-3",children:[(0,n.jsx)("div",{className:"w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg",children:(0,n.jsx)(f,{className:"w-5 h-5 text-white"})}),(0,n.jsxs)("div",{children:[(0,n.jsx)("h1",{className:"text-lg font-bold text-gray-900",children:"Health Tracker"}),(0,n.jsx)("p",{className:"text-xs text-gray-500",children:"个人健康管理"})]})]})}),(0,n.jsx)("nav",{className:"flex-1 p-3 overflow-y-auto",children:(0,n.jsx)("ul",{className:"space-y-1",children:k.map(e=>{let t=e.icon;return(0,n.jsx)("li",{children:(0,n.jsxs)("a",{href:e.href,onClick:r,className:"flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm transition-colors text-gray-600 hover:bg-gray-50 hover:text-gray-900",children:[(0,n.jsx)(t,{className:"w-5 h-5 text-gray-400"}),(0,n.jsx)("span",{children:e.label})]})},e.href)})})}),(0,n.jsx)("div",{className:"p-4 border-t border-gray-100",children:(0,n.jsx)("p",{className:"text-xs text-gray-400 text-center",children:"\xa9 2024 Health Tracker"})})]}),(0,n.jsx)("div",{className:"hidden lg:block w-64 flex-shrink-0"})]})}},81066:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});var n=r(2265),a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let r=(0,n.forwardRef)((r,i)=>{let{color:s="currentColor",size:c=24,strokeWidth:h=2,absoluteStrokeWidth:d,className:o="",children:y,...u}=r;return(0,n.createElement)("svg",{ref:i,...a,width:c,height:c,stroke:s,strokeWidth:d?24*Number(h)/Number(c):h,className:["lucide","lucide-".concat(l(e)),o].join(" "),...u},[...t.map(e=>{let[t,r]=e;return(0,n.createElement)(t,r)}),...Array.isArray(y)?y:[y]])});return r.displayName="".concat(e),r}},24241:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},22023:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},37663:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("Pill",[["path",{d:"m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z",key:"wa1lgi"}],["path",{d:"m8.5 8.5 7 7",key:"rvfmvr"}]])},55715:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("PlusCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]])},33907:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},52022:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},74697:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(81066).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},58877:function(){}},function(e){e.O(0,[404,971,23,744],function(){return e(e.s=93890)}),_N_E=e.O()}]);